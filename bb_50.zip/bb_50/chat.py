import csv
from csv import reader
from colorama import Fore, Back, Style
import colorama
colorama.init(autoreset=True)
import os, time
from time import sleep
from telethon.sync import TelegramClient
from telethon import utils
from telethon import errors
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.functions.messages import ImportChatInviteRequest, GetHistoryRequest
from telethon.tl.types import PeerUser, PeerChat, PeerChannel
from telethon import functions, types

r = Fore.RED
n = Fore.RESET
lg = Fore.GREEN
rs = Fore.RESET
w = Fore.WHITE
grey = '\033[97m'
cy = Fore.CYAN
ye = Fore.YELLOW
colors = [r, lg, w, ye, cy]
info = lg + '[' + w + 'i' + lg + ']' + rs
error = lg + '[' + r + '!' + lg + ']' + rs
success = w + '[' + lg + '*' + w + ']' + rs
INPUT = lg + '[' + cy + '~' + lg + ']' + rs
plus = w + '[' + lg + '+' + w + ']' + rs
minus = w + '[' + lg + '-' + w + ']' + rs
re="\033[1;31m"
gr="\033[1;32m"
wi="\033[1;35m"

api_id = '23269382'
api_hash = "fe19c565fb4378bd5128885428ff8e26"

def groupchatcloner():


    if os.path.exists(f'scrmessage.csv'):
        os.remove(f'scrmessage.csv')
    if not os.path.exists(f'scrmessage.csv'):
        fp = open('scrmessage.csv', 'x')
        fp.close()
        
    groupsc = str(input(f"{gr}Enter Target Group Username or Private Link: {re}"))
    groupyour = str(input(f"{gr}Enter Your Group Link: {re}"))
    groupmsg = int(input(f"{gr}Enter Number of messages you want to scrape: {re}"))
    delayper = int(input(f"{gr}Enter Delay Per Second between per Message: {re}"))
    def save_messages(message):
        with open('scrmessage.csv', 'a') as file:
           file.write(f"{message.id}\n")
        
    with open('phone.csv', 'r')as f:
        first_number = f.readline().strip()
        pphone = first_number
        if pphone:
            phone = utils.parse_phone(pphone)
            print(Style.BRIGHT + Fore.GREEN + f"Getting {phone}")
            app = TelegramClient(f'sessions/{phone}', api_id, api_hash)
            app.start(phone)
            try:
                code = groupsc.split('/')[-1]
                if '+' in groupsc:
                    ret = f'{code}'
                    try:
                        codeme = ret.replace('+', '')
                        app(ImportChatInviteRequest(codeme))
                    except errors.UserAlreadyParticipantError:
                        pass
                elif '/joinchat' in groupsc:
                    try:
                        app(ImportChatInviteRequest(code))
                    except errors.UserAlreadyParticipantError:
                        pass
                else:
                    app(JoinChannelRequest(groupsc))
            
            except errors.UserAlreadyParticipantError:
                pass
            try:
               sc_entity = app.get_entity(groupsc)
            except Exception as e:
               print(e)
            posts = app(GetHistoryRequest(peer=sc_entity, limit=1, offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))
            for messagee in posts.messages:
                rare = messagee.id - groupmsg
                messagess = app(GetHistoryRequest(peer=sc_entity, limit=groupmsg, offset_date=None, offset_id=rare, max_id=0, min_id=0, add_offset=0, hash=0))
                messages = sorted(messagess.messages, key=lambda x: x.id)
                for message in messages:
                     save_messages(message)
            app.disconnect()
            print()

    with open('phone.csv', 'r')as f:
        str_list = [row[0] for row in csv.reader(f)]
        po = 0
        for pphone in str_list:
            phone = utils.parse_phone(pphone)
            po += 1
            print(Style.BRIGHT + Fore.GREEN + f"Joining {phone}")
            app = TelegramClient(f'sessions/{phone}', api_id, api_hash)
            try:
                app.start(phone)
                code = groupsc.split('/')[-1]
                if '+' in groupsc:
                    ret = f'{code}'
                    try:
                        codeme = ret.replace('+', '')
                        app(ImportChatInviteRequest(codeme))
                    except errors.UserAlreadyParticipantError:
                        pass
                elif '/joinchat' in groupsc:
                    try:
                        app(ImportChatInviteRequest(code))
                    except errors.UserAlreadyParticipantError:
                        pass
                else:
                    app(JoinChannelRequest(groupsc))
            except errors.UserAlreadyParticipantError:
                pass
            time.sleep(2)
            try:
                codew = groupyour.split('/')[-1]
                if '+' in groupyour:
                    rett = f'{codew}'
                    try:
                        boldme = rett.replace('+', '')
                        app(ImportChatInviteRequest(boldme))
                    except errors.UserAlreadyParticipantError:
                        pass
                elif '/joinchat' in groupyour:
                    try:
                        app(ImportChatInviteRequest(codew))
                    except errors.UserAlreadyParticipantError:
                        pass
                else:
                    app(JoinChannelRequest(groupyour))
            except errors.UserAlreadyParticipantError:
                pass
            print(f'{wi}Join Successful')
            try:
                your_entity = app.get_entity(groupyour)
            except Exception as e:
                print(e)
            app.disconnect()
            print()
    
    with open('scrmessage.csv', 'r', encoding='utf-8') as f:
        message_ids = [int(line.strip()) for line in f]

    with open('phone.csv', 'r') as f:
        phone_numbers = [row[0] for row in csv.reader(f)]

    message_index = 0
    while message_index < len(message_ids):
        for pphone in phone_numbers:
            phone = utils.parse_phone(pphone)
            print(Style.BRIGHT + Fore.GREEN + f"Using {phone}")
        
            app = TelegramClient(f'sessions/{phone}', api_id, api_hash)
            app.start(phone)
            time.sleep(delayper)
            # Copy and send the message to "justtestog"
            try:
                fullinfomsg = app(functions.channels.GetMessagesRequest(channel=sc_entity.id, id=[message_ids[message_index]]))
                heho = fullinfomsg.messages[0]
                app.send_message(your_entity.id, heho)
            except Exception as e:
                print(e)
                pass
        
            app.disconnect()
            print(f"Message with ID {message_ids[message_index]} sent using {phone}")
        
            message_index += 1  # Move to the next message

            if message_index >= len(message_ids):
                break  # Stop the loop if all messages are sent

    print("All messages sent using available phone numbers.")

groupchatcloner()