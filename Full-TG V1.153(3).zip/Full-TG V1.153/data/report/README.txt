Make sure to fill in the files with which you want to report.
1 line = 1 report message
