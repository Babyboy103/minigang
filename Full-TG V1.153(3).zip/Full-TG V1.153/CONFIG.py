#You can edit the content of the emoji as you want. Dont change the name 'emoji'!
emoji = ['❤️', '🔥', '👍', '👎', '🥰', '👏', '😁', '🤔', '🤯', '🤬', '😢', '🎉', '🤩', '🤮', '💩', '🙏', '👌', '🤡', '🥱', '🥴', '🐳', '🌚', '💯', '💔', '🤨', '💋', '🖕', '😈', '🥱', '😭', '🤓', '👀', '🤝', '😎', '😘']
